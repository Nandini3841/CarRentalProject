abstract class CarEvent {}

class LoadCars extends CarEvent {}
